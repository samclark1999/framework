<?php

namespace ACP\Column;

use AC;

/**
 * @deprecated 4.2.4
 */
class Menu extends AC\Column {

	// Deprecated. Should be removed at some point.

}